#!/usr/bin/env python3
"""
Run the India CPI inflation forecasting pipeline end to end.

Usage:
    python run.py
    python run.py --horizon 6
    python run.py --data path/to/official_cpi.csv --horizon 12

By default this uses the illustrative historical series described in
docs/METHODOLOGY.md. Pass --data with a two column CSV (date,
cpi_inflation_yoy) to use a real series instead, for example the
official MOSPI or RBI monthly release.
"""

import argparse
import os
import warnings

warnings.filterwarnings("ignore")

import pandas as pd

from src.inflation_forecast.data import build_historical_series, load_from_csv
from src.inflation_forecast.features import engineer_features, feature_columns
from src.inflation_forecast.model import build_models, evaluate_models
from src.inflation_forecast.forecast import recursive_forecast, recursive_forecast_with_interval
from src.inflation_forecast.plotting import plot_forecast


def parse_args():
    parser = argparse.ArgumentParser(description="India CPI inflation forecasting pipeline")
    parser.add_argument("--data", type=str, default=None,
                         help="Path to a two column CSV, date and cpi_inflation_yoy. "
                              "If omitted, uses the built in illustrative series.")
    parser.add_argument("--horizon", type=int, default=12,
                         help="Number of months to forecast ahead. Default 12.")
    parser.add_argument("--output-dir", type=str, default="outputs",
                         help="Directory to save the forecast CSV and chart. Default outputs.")
    parser.add_argument("--random-state", type=int, default=42,
                         help="Random seed for reproducibility. Default 42.")
    return parser.parse_args()


def main():
    args = parse_args()
    os.makedirs(args.output_dir, exist_ok=True)

    if args.data:
        history = load_from_csv(args.data)
        print(f"Loaded {len(history)} monthly observations from {args.data}")
    else:
        history = build_historical_series(random_state=args.random_state)
        print("Using the built in illustrative historical series, see docs/METHODOLOGY.md")

    print(f"Coverage: {history['date'].min().date()} to {history['date'].max().date()}, "
          f"{len(history)} monthly observations\n")

    features = engineer_features(history).dropna().reset_index(drop=True)
    feature_cols = feature_columns(features)
    X, y = features[feature_cols], features["cpi_inflation_yoy"]
    print(f"Feature matrix ready: {X.shape[0]} rows, {X.shape[1]} predictors\n")

    models = build_models(random_state=args.random_state)

    print("Cross validated accuracy, five time ordered folds")
    cv_scores = evaluate_models(X, y, models)
    for name, score in cv_scores.items():
        print(f"  {name:14s} mean absolute error {score['mae']:.2f} points, "
              f"root mean square error {score['rmse']:.2f} points")

    best_name = min(cv_scores, key=lambda k: cv_scores[k]["mae"])
    print(f"\nLowest error on unseen months: {best_name}\n")

    for model in models.values():
        model.fit(X, y)

    forest = models["random_forest"]
    booster = models["xgboost"]

    _, forest_path = recursive_forecast(history, forest, feature_cols, horizon=args.horizon)
    _, booster_path = recursive_forecast(history, booster, feature_cols, horizon=args.horizon)
    lower_band, _, upper_band = recursive_forecast_with_interval(
        history, forest, feature_cols, horizon=args.horizon
    )

    future_dates = pd.date_range(
        history["date"].max() + pd.DateOffset(months=1), periods=args.horizon, freq="MS"
    )
    ensemble_path = (forest_path + booster_path) / 2

    forecast_table = pd.DataFrame({
        "date": future_dates,
        "random_forest": forest_path.round(2),
        "xgboost": booster_path.round(2),
        "ensemble": ensemble_path.round(2),
        "lower_band_10th_percentile": lower_band.round(2),
        "upper_band_90th_percentile": upper_band.round(2),
    })

    csv_path = os.path.join(args.output_dir, "forecast.csv")
    forecast_table.to_csv(csv_path, index=False)

    print(f"{args.horizon} month forecast, year on year CPI inflation, percent")
    print(forecast_table.to_string(index=False))

    importance = pd.Series(forest.feature_importances_, index=feature_cols)
    print("\nWhich patterns the model leans on most, random forest importances")
    print(importance.sort_values(ascending=False).head(8).round(3).to_string())

    chart_path = os.path.join(args.output_dir, "forecast_chart.png")
    plot_forecast(history, future_dates, ensemble_path, lower_band, upper_band,
                  forest_path, booster_path, output_path=chart_path)
    print(f"\nSaved {csv_path} and {chart_path}")


if __name__ == "__main__":
    main()
