"""
Sanity tests for the inflation forecasting pipeline.

These are not a substitute for real backtesting against official data,
they exist to catch broken code, not to validate forecast accuracy.
Run with: pytest
"""

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import numpy as np
import pandas as pd

from src.inflation_forecast.data import build_historical_series
from src.inflation_forecast.features import engineer_features, feature_columns
from src.inflation_forecast.model import build_models, evaluate_models
from src.inflation_forecast.forecast import recursive_forecast, recursive_forecast_with_interval


def test_historical_series_shape():
    history = build_historical_series()
    assert len(history) == 156
    assert list(history.columns) == ["date", "cpi_inflation_yoy"]
    assert history["cpi_inflation_yoy"].between(-1, 13).all()


def test_features_have_no_lookahead_leak():
    history = build_historical_series()
    features = engineer_features(history)
    # lag_1 for row i should equal cpi_inflation_yoy at row i - 1
    aligned = features["lag_1"].iloc[1:].reset_index(drop=True)
    shifted = history["cpi_inflation_yoy"].iloc[:-1].reset_index(drop=True)
    assert np.allclose(aligned.dropna(), shifted.iloc[-len(aligned.dropna()):])


def test_feature_columns_excludes_date_and_target():
    history = build_historical_series()
    features = engineer_features(history)
    cols = feature_columns(features)
    assert "date" not in cols
    assert "cpi_inflation_yoy" not in cols
    assert "lag_1" in cols


def test_models_train_and_forecast():
    history = build_historical_series()
    features = engineer_features(history).dropna().reset_index(drop=True)
    cols = feature_columns(features)
    X, y = features[cols], features["cpi_inflation_yoy"]

    models = build_models()
    scores = evaluate_models(X, y, models)
    assert set(scores.keys()) == {"random_forest", "xgboost"}
    for score in scores.values():
        assert score["mae"] > 0
        assert score["rmse"] >= score["mae"]

    for model in models.values():
        model.fit(X, y)

    forest = models["random_forest"]
    dates, path = recursive_forecast(history, forest, cols, horizon=6)
    assert len(dates) == 6
    assert len(path) == 6
    assert np.isfinite(path).all()


def test_confidence_interval_ordering():
    history = build_historical_series()
    features = engineer_features(history).dropna().reset_index(drop=True)
    cols = feature_columns(features)
    X, y = features[cols], features["cpi_inflation_yoy"]

    models = build_models()
    models["random_forest"].fit(X, y)
    forest = models["random_forest"]

    lower, median, upper = recursive_forecast_with_interval(history, forest, cols, horizon=6)
    assert (lower <= median).all()
    assert (median <= upper).all()
