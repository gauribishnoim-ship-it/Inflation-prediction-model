"""
Historical CPI inflation data for India.

The exact monthly print of India's CPI (Combined) inflation is published
by MOSPI and archived by the Reserve Bank of India. This project has no
live connection to either source, so the series below is rebuilt from
well documented turning points in that history rather than invented
outright: the high inflation of 2013, the low point in mid 2017, the
onion price shock at the end of 2019, the pandemic supply disruption of
2020, the oil and war driven spike of 2022, the tomato price shock of
mid 2023, and the disinflation toward the Reserve Bank's four percent
target through 2024 and 2025. Monthly values are produced by
interpolating between these anchor points and adding a small amount of
noise consistent with how noisy real monthly prints tend to be.

Before this model is used for anything beyond demonstration, replace
ANCHORS and build_historical_series with a loader for the official
series from mospi.gov.in or dbie.rbi.org.in. Everything downstream reads
only two columns, date and cpi_inflation_yoy, so no other module needs
to change.
"""

import numpy as np
import pandas as pd

ANCHORS = {
    "2013-01": 10.2, "2013-06": 9.9, "2013-12": 9.9,
    "2014-06": 7.3, "2014-12": 4.3,
    "2015-06": 5.4, "2015-12": 5.6,
    "2016-06": 5.8, "2016-12": 3.4,
    "2017-06": 1.5, "2017-12": 5.2,
    "2018-06": 5.0, "2018-12": 2.2,
    "2019-06": 3.2, "2019-12": 7.4,
    "2020-06": 6.2, "2020-10": 7.6, "2020-12": 4.6,
    "2021-06": 6.3, "2021-12": 5.7,
    "2022-04": 7.8, "2022-06": 7.0, "2022-12": 5.7,
    "2023-07": 7.4, "2023-12": 5.7,
    "2024-06": 5.1, "2024-12": 5.2,
    "2025-06": 2.8, "2025-12": 2.3,
}

START_DATE = "2013-01-01"
END_DATE = "2025-12-01"


def build_historical_series(random_state: int = 42) -> pd.DataFrame:
    """Return a monthly DataFrame with columns date and cpi_inflation_yoy.

    See the module docstring for what this series is and is not.
    """
    rng = np.random.default_rng(random_state)

    anchor_series = pd.Series(ANCHORS)
    anchor_series.index = pd.to_datetime(anchor_series.index)
    anchor_series = anchor_series.sort_index()

    monthly_index = pd.date_range(START_DATE, END_DATE, freq="MS")
    monthly = anchor_series.reindex(monthly_index).interpolate(method="linear")
    monthly = monthly + rng.normal(0, 0.25, size=len(monthly))
    monthly = monthly.clip(lower=-1, upper=13)

    return pd.DataFrame({
        "date": monthly.index,
        "cpi_inflation_yoy": monthly.values.round(2),
    })


def load_from_csv(path: str) -> pd.DataFrame:
    """Load a real CPI series from a two column CSV, date and cpi_inflation_yoy.

    Use this in place of build_historical_series once you have the
    official MOSPI or RBI monthly series saved locally.
    """
    frame = pd.read_csv(path, parse_dates=["date"])
    frame = frame.sort_values("date").reset_index(drop=True)
    return frame[["date", "cpi_inflation_yoy"]]
