"""Chart of observed history alongside the forecast and its confidence band."""

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd


def plot_forecast(history: pd.DataFrame, future_dates, ensemble_path,
                   lower_band, upper_band, forest_path, booster_path,
                   output_path: str = "outputs/forecast_chart.png",
                   rbi_target: float = 4.0) -> None:
    plt.figure(figsize=(12.5, 6.2))

    plt.plot(history["date"], history["cpi_inflation_yoy"],
              color="#1d4ed8", linewidth=1.6, label="Observed CPI inflation")

    plt.fill_between(future_dates, lower_band, upper_band,
                       color="#dc2626", alpha=0.15, label="10th to 90th percentile range")

    plt.plot(future_dates, forest_path, color="#16a34a", linestyle="--",
              linewidth=1.3, marker="o", markersize=3.5, label="Random forest path")
    plt.plot(future_dates, booster_path, color="#ea580c", linestyle="--",
              linewidth=1.3, marker="s", markersize=3.5, label="XGBoost path")
    plt.plot(future_dates, ensemble_path, color="#b91c1c", linewidth=2.1,
              marker="D", markersize=4.5, label="Ensemble forecast")

    plt.axhline(rbi_target, color="#374151", linestyle=":", linewidth=1, alpha=0.7,
                 label=f"Reserve Bank target, {rbi_target:g} percent")
    plt.axvline(history["date"].max(), color="#9ca3af", linestyle=":", linewidth=1)

    plt.title("India CPI Inflation, Observed History and Forecast",
               fontsize=13.5, fontweight="bold")
    plt.xlabel("Date")
    plt.ylabel("Year on year CPI inflation, percent")
    plt.legend(loc="upper right", fontsize=8.7, framealpha=0.9)
    plt.grid(alpha=0.25)
    plt.tight_layout()
    plt.savefig(output_path, dpi=160)
    plt.close()
