"""
Model construction and validation.

A five fold time ordered split is used instead of an ordinary random
split. An ordinary split would let the model train on March 2024 and be
tested on January 2024, which is a forecast in reverse and gives an
unrealistically flattering score. The time ordered split always trains
on the past and tests on the future, matching how the model will
actually be used.
"""

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import mean_absolute_error, mean_squared_error

RANDOM_STATE = 42


def build_models(random_state: int = RANDOM_STATE) -> dict:
    """Return a dict of untrained model_name -> estimator."""
    from xgboost import XGBRegressor

    return {
        "random_forest": RandomForestRegressor(
            n_estimators=400, max_depth=6, min_samples_leaf=2,
            random_state=random_state,
        ),
        "xgboost": XGBRegressor(
            n_estimators=400, max_depth=3, learning_rate=0.03,
            subsample=0.8, colsample_bytree=0.8, random_state=random_state,
        ),
    }


def evaluate_models(X: pd.DataFrame, y: pd.Series, models: dict, n_splits: int = 5) -> dict:
    """Time ordered cross validation. Returns model_name -> {mae, rmse}.

    Note: this fits each model on each fold internally and leaves the
    models fitted on the final fold when it returns. Call model.fit(X, y)
    again on the full dataset afterward if you want a model trained on
    everything.
    """
    splitter = TimeSeriesSplit(n_splits=n_splits)
    results = {}

    for name, model in models.items():
        fold_mae, fold_rmse = [], []
        for train_idx, test_idx in splitter.split(X):
            model.fit(X.iloc[train_idx], y.iloc[train_idx])
            prediction = model.predict(X.iloc[test_idx])
            fold_mae.append(mean_absolute_error(y.iloc[test_idx], prediction))
            fold_rmse.append(
                np.sqrt(mean_squared_error(y.iloc[test_idx], prediction))
            )
        results[name] = {
            "mae": float(np.mean(fold_mae)),
            "rmse": float(np.mean(fold_rmse)),
        }

    return results
