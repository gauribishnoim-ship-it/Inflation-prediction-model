"""
inflation_forecast
===================

A small, honestly validated machine learning pipeline for forecasting
India's CPI inflation using Random Forest and XGBoost.

See the project README for background and docs/METHODOLOGY.md for the
full reasoning behind each design choice.
"""

from .data import build_historical_series
from .features import engineer_features
from .model import build_models, evaluate_models
from .forecast import recursive_forecast, recursive_forecast_with_interval

__all__ = [
    "build_historical_series",
    "engineer_features",
    "build_models",
    "evaluate_models",
    "recursive_forecast",
    "recursive_forecast_with_interval",
]

__version__ = "1.0.0"
