"""
Feature engineering for the inflation model.

Each row describes one month using only information that would have
been known at the time, so the model cannot cheat by looking into its
own future during training.

  lag_1 ... lag_n     the last n monthly readings
  roll_mean_k         the average of the last k months, trend
  roll_std_k          the spread of the last k months, volatility
  momentum_k          how much the rate has moved over k months
  month_sin/cos       a smooth encoding of the calendar month, so the
                      model can learn seasonal food price patterns
                      without treating December and January as
                      numerically distant
"""

import numpy as np
import pandas as pd

DEFAULT_N_LAGS = 12


def engineer_features(data: pd.DataFrame, n_lags: int = DEFAULT_N_LAGS) -> pd.DataFrame:
    """Return data with added predictor columns. Rows with insufficient
    history for the lags will contain NaN and should be dropped by the
    caller before training."""
    frame = data.copy()

    for lag in range(1, n_lags + 1):
        frame[f"lag_{lag}"] = frame["cpi_inflation_yoy"].shift(lag)

    for window in (3, 6, 12):
        frame[f"roll_mean_{window}"] = (
            frame["cpi_inflation_yoy"].shift(1).rolling(window).mean()
        )
    for window in (3, 6):
        frame[f"roll_std_{window}"] = (
            frame["cpi_inflation_yoy"].shift(1).rolling(window).std()
        )

    frame["momentum_3"] = frame["lag_1"] - frame["lag_3"]
    frame["momentum_6"] = frame["lag_1"] - frame["lag_6"]

    month = frame["date"].dt.month
    frame["month_sin"] = np.sin(2 * np.pi * month / 12)
    frame["month_cos"] = np.cos(2 * np.pi * month / 12)

    return frame


def feature_columns(feature_frame: pd.DataFrame) -> list:
    """Return the list of predictor column names, excluding date and target."""
    return [c for c in feature_frame.columns if c not in ("date", "cpi_inflation_yoy")]
