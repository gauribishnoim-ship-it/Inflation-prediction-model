"""
Recursive forecasting with confidence bands.

To predict several months ahead, the model predicts month one, treats
that prediction as if it were an observed value, and uses it to predict
month two, and so on. This mirrors how a forecaster with no other
information would have to proceed, and it is also why the further
months of a forecast deserve less trust than the nearer ones, any early
error compounds forward.

The confidence band comes from the individual decision trees inside a
Random Forest. Each tree produces its own forecast path; the tenth and
ninetieth percentile across all trees at each future month gives a data
driven interval rather than an assumed one.
"""

import numpy as np
import pandas as pd

from .features import engineer_features, feature_columns, DEFAULT_N_LAGS


def recursive_forecast(history: pd.DataFrame, model, feature_cols: list,
                        horizon: int = 12, n_lags: int = DEFAULT_N_LAGS):
    """Forecast horizon months ahead using model, one step at a time.

    Returns (future_dates, point_forecast) where point_forecast is a
    numpy array of length horizon.
    """
    working_history = history.copy()
    last_date = working_history["date"].max()
    future_dates = pd.date_range(
        last_date + pd.DateOffset(months=1), periods=horizon, freq="MS"
    )

    point_forecast = []
    for future_date in future_dates:
        candidate = pd.concat(
            [working_history,
             pd.DataFrame({"date": [future_date], "cpi_inflation_yoy": [np.nan]})],
            ignore_index=True,
        )
        features = engineer_features(candidate, n_lags=n_lags)
        x_new = features[feature_cols].iloc[[-1]]
        prediction = model.predict(x_new)[0]
        point_forecast.append(prediction)
        working_history = pd.concat(
            [working_history,
             pd.DataFrame({"date": [future_date], "cpi_inflation_yoy": [prediction]})],
            ignore_index=True,
        )

    return future_dates, np.array(point_forecast)


def recursive_forecast_with_interval(history: pd.DataFrame, forest, feature_cols: list,
                                      horizon: int = 12, n_lags: int = DEFAULT_N_LAGS,
                                      lower_pct: int = 10, upper_pct: int = 90):
    """Use every tree inside a fitted RandomForestRegressor to build a
    distribution of forecast paths, then return lower, median, upper
    percentile arrays, each of length horizon.
    """
    tree_paths = []
    for tree in forest.estimators_:
        _, path = recursive_forecast(history, tree, feature_cols, horizon, n_lags)
        tree_paths.append(path)
    tree_paths = np.array(tree_paths)

    lower = np.percentile(tree_paths, lower_pct, axis=0)
    median = np.percentile(tree_paths, 50, axis=0)
    upper = np.percentile(tree_paths, upper_pct, axis=0)

    return lower, median, upper
